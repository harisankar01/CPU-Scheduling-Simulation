from .FCFS import FCFS
from .SJF import SJF
from .RoundRobin import Round_Robin